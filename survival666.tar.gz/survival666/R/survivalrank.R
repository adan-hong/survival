#' @title
#' Rank the significance of survival analysis
#' @description
#' This data file is actually the output of super_survival function.
#' The significance P value of survival analysis for each gene in survivaldata
#' matrix were recorded
"survivalrank"
