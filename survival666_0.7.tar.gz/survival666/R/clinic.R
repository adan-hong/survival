#' @title
#' Clinical records of overall survival
#' @description
#' This is a document that records the overall survival rate.
#' @source \url{https://xenabrowser.net/datapages/}
"clinic"
